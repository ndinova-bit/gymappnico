-- Migración v12: limpia ejercicios repetidos del catálogo BASE (user_id nulo).
-- No toca tus ejercicios propios, ni series, ni rutinas, ni sesiones.
-- La app ya oculta los repetidos sin necesidad de este paso: es solo orden en la base.
-- Se puede ejecutar más de una vez sin problema.

-- Paso 1: mirá cuántos repetidos hay (solo lectura).
select count(*) as filas_repetidas
from public.ejercicios a
join public.ejercicios b
  on a.user_id is null and b.user_id is null and a.nombre = b.nombre and a.ctid > b.ctid;

-- Paso 2: si el número del paso 1 te cierra, ejecutá esto. Deja una sola fila por nombre.
delete from public.ejercicios a
using public.ejercicios b
where a.user_id is null and b.user_id is null
  and a.nombre = b.nombre
  and a.ctid > b.ctid;
